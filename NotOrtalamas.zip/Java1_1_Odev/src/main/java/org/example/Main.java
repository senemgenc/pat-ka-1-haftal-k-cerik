package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {



        int mat, fizik,kimya, turkce ,tarih ,muzik;
        Scanner  scanner = new Scanner(System.in);


        System.out.println("Matematiik Notunuz : ");
        mat = scanner.nextInt();

        System.out.println("Fizik Notunuz : ");
        fizik = scanner.nextInt();

        System.out.println("Kimya Notunuz : ");
        kimya = scanner.nextInt();

        System.out.println("Türkçe Notunuz : ");
        turkce = scanner.nextInt();

        System.out.println("Tarih Notunuz : ");
        tarih = scanner.nextInt();

        System.out.println("Muzik Notunuz : ");
        muzik = scanner.nextInt();

        int toplam = (mat+ fizik + kimya + turkce + tarih + muzik);

        double sonuc =toplam / 6.0;

        String gectiMi = sonuc >= 60 ? "Geçtiniz" : "Kaldınız";
        System.out.println( gectiMi);
    }
}